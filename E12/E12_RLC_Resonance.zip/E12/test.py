import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

# Gaussian model for fitting
def Gauss(x, a, x0, sigma):
    return a * np.exp(-(x - x0)**2 / (2 * sigma**2))

# Constants
r1 = 220      # Ohms ±5%
r2 = 10       # Ohms ±5%
L  = 1.5e-3   # Henry

# Load series data
data1 = pd.read_csv('Series_R1.csv').to_numpy()
data2 = pd.read_csv('Series_R2.csv').to_numpy()

f1 = data1[:,2].astype(float)
A1 = data1[:,1].astype(float)
f2 = data2[:,2].astype(float)
A2 = data2[:,1].astype(float)

# Noise filtering
mask1 = A1 > 0.01
mask2 = A2 > 0.07
f1, A1 = f1[mask1], A1[mask1]
f2, A2 = f2[mask2], A2[mask2]

# Frequency window around resonance
window = (f1 >= 1600) & (f1 <= 9000)
f1, A1 = f1[window], A1[window]
window = (f2 >= 1600) & (f2 <= 9000)
f2, A2 = f2[window], A2[window]

# Estimate initial fit params
mean1 = np.sum(f1*A1)/np.sum(A1)
sig1  = np.sqrt(np.sum(A1*(f1-mean1)**2)/np.sum(A1))
mean2 = np.sum(f2*A2)/np.sum(A2)
sig2  = np.sqrt(np.sum(A2*(f2-mean2)**2)/np.sum(A2))

# Curve fitting
popt1, _ = curve_fit(Gauss, f1, A1, p0=[max(A1), mean1, sig1])
popt2, _ = curve_fit(Gauss, f2, A2, p0=[max(A2), mean2, sig2])

fit1 = Gauss(f1, *popt1)
fit2 = Gauss(f2, *popt2)

# Plot resonance curves
plt.figure()
plt.plot(f1/1000, A1*1000, '.', label=f'R_d = {r1} Ω')
plt.plot(f1/1000, fit1*1000, '-', label='Gaussian fit')
plt.plot(f2/1000, A2*1000, '.', label=f'R_d = {r2} Ω')
plt.plot(f2/1000, fit2*1000, '-', label='Gaussian fit')
plt.xlabel('Frequency (kHz)')
plt.ylabel('Voltage $U_R$ (mV)')
plt.title('Series Resonance Curves')
plt.legend()
plt.show()

# Resonance frequency (average of both fits)
f0 = 0.5*(popt1[1] + popt2[1])

# Full Width at Half Maximum
FWHM1 = 2*np.sqrt(2*np.log(2))*popt1[2]
FWHM2 = 2*np.sqrt(2*np.log(2))*popt2[2]

# Damping constants
delta1 = np.pi * FWHM1
delta2 = np.pi * FWHM2

# Quality factors
Q1 = f0 / FWHM1
Q2 = f0 / FWHM2

print(f"Series R={r1}Ω: Δf={FWHM1:.1f} Hz, δ={delta1:.3f}, Q={Q1:.1f}")
print(f"Series R={r2}Ω: Δf={FWHM2:.1f} Hz, δ={delta2:.3f}, Q={Q2:.1f}")

# Capacitance calculation
C = 1/(L*(2*np.pi*f0)**2)
print(f"Calculated C = {C*1e9:.2f} nF")

# Load parallel dataset
data_p = pd.read_csv('Parallel_R1.csv')
freq_p = data_p.iloc[:, 2].astype(float)
A_p = data_p.iloc[:, 1].astype(float)

# Noise filtering threshold
mask = A_p > 0.01
freq_p = freq_p[mask]
A_p = A_p[mask]

# Plot raw resonance curve
plt.figure()
plt.plot(freq_p/1000, A_p*1000, 'o', label='Measured $U_R(f)$')
plt.xlabel('Frequency (kHz)')
plt.ylabel('Voltage across $R_d$ (mV)')
plt.title('Parallel Resonance Curve')
plt.legend()
plt.show()

# Model function for I(f) under constant U0
def I_model(f, L, C, Rsp, Rd, U0):
    omega = 2 * np.pi * f
    Z_L = Rsp + 1j * omega * L
    Y_LC = 1.0 / Z_L + 1j * omega * C
    Y_tot = 1.0 / Rd + Y_LC
    Z_tot = 1.0 / Y_tot
    return U0 / np.abs(Z_tot)

# Initial guesses for parameters
p0 = [1.5e-3, 50e-9, 1.0, 220.0, max(A_p)]

# Perform curve fit
popt_p, pcov_p = curve_fit(
    I_model,
    freq_p,
    A_p,
    p0=p0,
    bounds=(
        [1e-4, 1e-11, 0.1, 10, 0],    # lower bounds
        [1e-2, 1e-6, 10, 1000, np.inf] # upper bounds
    )
)
L_fit, C_fit, Rsp_fit, Rd_fit, U0_fit = popt_p

print(f"Fitted parameters:\n  L = {L_fit:.3e} H\n  C = {C_fit:.3e} F\n  RSp = {Rsp_fit:.1f} Ω\n  Rd = {Rd_fit:.1f} Ω\n  U0 = {U0_fit:.3f} V")

# Parallel resonance frequency
f0_parallel = 1 / (2 * np.pi * np.sqrt(L_fit * C_fit))
print(f"Parallel f0 = {f0_parallel/1000:.2f} kHz")
print(f"Series   f0 = {f0/1000:.2f} kHz   (Task 2)")