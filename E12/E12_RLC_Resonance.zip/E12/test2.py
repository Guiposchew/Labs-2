import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

# Lorentzian function (more accurate for resonance curves)
def lorentzian(f, a, f0, gamma):
    return a / (1 + ((f - f0)/gamma)**2)

# Constants
r1 = 220      # Ohms ±5%
r2 = 10       # Ohms ±5%
L_known = 1.5e-3  # H (used in series only)

# Load series data
data1 = pd.read_csv('Series_R1.csv').to_numpy()
data2 = pd.read_csv('Series_R2.csv').to_numpy()
f1, A1 = data1[:, 2].astype(float), data1[:, 1].astype(float)
f2, A2 = data2[:, 2].astype(float), data2[:, 1].astype(float)

# Filter noise and frequency range
mask1 = (A1 > 0.01) & (f1 >= 1600) & (f1 <= 9000)
mask2 = (A2 > 0.07) & (f2 >= 1600) & (f2 <= 9000)
f1, A1 = f1[mask1], A1[mask1]
f2, A2 = f2[mask2], A2[mask2]

# Initial guess for fit params
p0_1 = [max(A1), f1[np.argmax(A1)], 500]
p0_2 = [max(A2), f2[np.argmax(A2)], 500]

# Lorentzian curve fitting
popt1, _ = curve_fit(lorentzian, f1, A1, p0=p0_1)
popt2, _ = curve_fit(lorentzian, f2, A2, p0=p0_2)
fit1 = lorentzian(f1, *popt1)
fit2 = lorentzian(f2, *popt2)

# Plotting
plt.figure()
plt.plot(f1/1000, A1*1000, '.', label=f'R_d = {r1} Ω')
plt.plot(f1/1000, fit1*1000, '-', label='Lorentzian fit')
plt.plot(f2/1000, A2*1000, '.', label=f'R_d = {r2} Ω')
plt.plot(f2/1000, fit2*1000, '-', label='Lorentzian fit')
plt.xlabel('Frequency (kHz)')
plt.ylabel('Voltage $U_R$ (mV)')
plt.title('Series Resonance Curves (Lorentzian)')
plt.legend()
plt.show()

# Extract resonance info
f0_1, f0_2 = popt1[1], popt2[1]
gamma1, gamma2 = popt1[2], popt2[2]
FWHM1, FWHM2 = 2 * gamma1, 2 * gamma2
f0_avg = (f0_1 + f0_2) / 2

# Damping constants and quality factors
delta1 = np.pi * FWHM1
delta2 = np.pi * FWHM2
Q1 = f0_avg / FWHM1
Q2 = f0_avg / FWHM2

# Capacitance estimate using f0_avg
C_est = 1 / (L_known * (2 * np.pi * f0_avg)**2)

print(f"Series R={r1}Ω: f0={f0_1:.1f} Hz, Δf={FWHM1:.1f} Hz, δ={delta1:.3f}, Q={Q1:.1f}")
print(f"Series R={r2}Ω: f0={f0_2:.1f} Hz, Δf={FWHM2:.1f} Hz, δ={delta2:.3f}, Q={Q2:.1f}")
print(f"Estimated C = {C_est*1e9:.2f} nF")

# ---------- Parallel Resonance Part (unchanged) ----------

# Load and filter parallel data
data_p = pd.read_csv('Parallel_R1.csv')
freq_p = data_p.iloc[:, 2].astype(float)
A_p = data_p.iloc[:, 1].astype(float)
mask_p = A_p > 0.01
freq_p, A_p = freq_p[mask_p], A_p[mask_p]

# Plot measured curve
plt.figure()
plt.plot(freq_p/1000, A_p*1000, 'o', label='Measured $U_R(f)$')
plt.xlabel('Frequency (kHz)')
plt.ylabel('Voltage across $R_d$ (mV)')
plt.title('Parallel Resonance Curve')
plt.legend()
plt.show()

# Impedance-based current model
def I_model(f, L, C, Rsp, Rd, U0):
    omega = 2 * np.pi * f
    Z_L = Rsp + 1j * omega * L
    Y_LC = 1.0 / Z_L + 1j * omega * C
    Y_tot = 1.0 / Rd + Y_LC
    Z_tot = 1.0 / Y_tot
    return U0 / np.abs(Z_tot)

# Fit model to parallel data
p0_parallel = [1.5e-3, 50e-9, 1.0, 220.0, max(A_p)]
bounds = ([1e-4, 1e-11, 0.1, 10, 0], [1e-2, 1e-6, 10, 1000, np.inf])
popt_p, _ = curve_fit(I_model, freq_p, A_p, p0=p0_parallel, bounds=bounds)

L_fit, C_fit, Rsp_fit, Rd_fit, U0_fit = popt_p
f0_parallel = 1 / (2 * np.pi * np.sqrt(L_fit * C_fit))

print(f"\nParallel fit results:")
print(f"  L = {L_fit:.3e} H")
print(f"  C = {C_fit:.3e} F")
print(f"  RSp = {Rsp_fit:.1f} Ω")
print(f"  Rd = {Rd_fit:.1f} Ω")
print(f"  U0 = {U0_fit:.3f} V")
print(f"  Parallel f0 = {f0_parallel/1000:.2f} kHz")
print(f"  Series f0 (avg) = {f0_avg/1000:.2f} kHz")
